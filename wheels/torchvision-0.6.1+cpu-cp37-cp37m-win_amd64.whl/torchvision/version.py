__version__ = '0.6.1+cpu'
git_version = 'fe36f0663e231b9c875ad727cd76bc0922c9437b'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
